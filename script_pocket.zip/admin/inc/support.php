<?php

    /*!
	 * POCKET v3.4
	 *
	 * http://www.droidoxy.com
	 * support@droidoxy.com
	 *
	 * Copyright 2019 DroidOXY ( http://www.droidoxy.com )
	 */

?>
					<div class="col-12 mt-4">
                        <div class="block mb-4">
                            <div class="block-heading">
                                <h6>Support ?</h6>
                            </div>
                            <p>If you have any issues or problems with the code, please open a ticket in our Support Forum : <a href="https://www.droidoxy.com/support" target="_blank" data-toggle="tooltip" title="" data-original-title="Goto Support Forum" class="btn-link">www.droidoxy.com/support</a></p>
                        </div>
                    </div>