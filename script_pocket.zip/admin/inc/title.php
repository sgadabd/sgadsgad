<?php

    /*!
	 * POCKET v3.4
	 *
	 * http://www.droidoxy.com
	 * support@droidoxy.com
	 *
	 * Copyright 2019 DroidOXY ( http://www.droidoxy.com )
	 */

?>

    <meta content="pocket android rewards app droidoxy earn webpanel admin panel money making machine" name="keywords" />
    <meta content="DroidOXY" name="author" />
    <meta content="Admin | Pocket - Money Making Script by DroidOXY" name="description" />
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>Pocket - Money Making Script by DroidOXY</title>

    <!--favicon-->
    <link href="./assets/images/favicon.ico" rel="shortcut icon" />
