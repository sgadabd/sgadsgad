<?php

    /*!
	 * POCKET v3.7
	 *
	 * http://www.droidoxy.com
	 * support@droidoxy.com
	 *
	 * Copyright 2020 DroidOXY ( http://www.droidoxy.com )
	 */

?>
	    
	    <!-- Favicon -->
		<link rel="shortcut icon" href="../admin/assets/images/<?php echo $configs->getConfig('SITE_FAVICON'); ?>" />

		<meta charset="utf-8" />
		<title><?php echo $APP_NAME; ?> | <?php echo $APP_DESC; ?></title>
		<meta name="description" content="Pocket | Money Making Scripy by DroidOXY">