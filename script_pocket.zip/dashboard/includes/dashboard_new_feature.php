<?php

    /*!
	 * POCKET v3.7
	 *
	 * http://www.droidoxy.com
	 * support@droidoxy.com
	 *
	 * Copyright 2020 DroidOXY ( http://www.droidoxy.com )
	 */

?>
                                        <div class="kt-portlet kt-widget19">
                                            <div class="kt-portlet__body kt-portlet__body--fit kt-portlet__body--unfill">
                                                <div class="widget-new-feature kt-widget19__pic kt-portlet-fit--top kt-portlet-fit--sides">
                                                    <h3 class="kt-widget19__title kt-font-light">
                                                        Introducing Refer & Earn
                                                    </h3>
                                                    <div class="kt-widget19__shadow"></div>
                                                    <div class="kt-widget19__labels">
                                                        <a href="#" class="btn btn-label-light-o2 btn-bold ">NEW</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="kt-portlet__body">
                                                <div class="kt-widget19__wrapper">
                                                    <div class="kt-widget19__text">
                                                        Introducing an option to earn even more with our Featured Refer & Earn option. Refer friends and family to get benefit from our Refer & Earn Feature.
                                                    </div>
                                                </div>
                                                <div class="kt-widget19__action">
                                                    <a href="refer.php" class="btn btn-block btn-label-brand btn-bold"><i class="fa fa-hand-holding-usd"></i> Refer Friends</a>
                                                </div>
                                            </div>
                                        </div>